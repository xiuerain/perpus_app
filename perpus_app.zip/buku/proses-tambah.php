<?php
if($_POST) {
    include '../config/Database.php';
    include '../object/buku.php';

    $database = new Database();
    $db = $database->getConnection();

    $buku = new buku($db);

    $buku->ISBN = $_POST["ISBN"];
    $buku->Judul = $_POST["Judul"];
    $buku->Pengarang = $_POST["Pengarang"];
    $buku->Kategori_ID = $_POST["kategori_id"];
    $buku->Penerbit_ID = $_POST["penerbit_id"];
    $buku->Deskripsi = $_POST["deskripsi"];
    $buku->Stok = $_POST["Stok"];

    $buku->create();
}
header("Location: http://localhost/perpus_app/buku/index.php");
?>