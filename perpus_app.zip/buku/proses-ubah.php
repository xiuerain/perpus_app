<?php
if($_POST) {

    include '../config/Database.php';
    include '../object/buku.php';

    $database = new Database();
    $db = $database->getConnection();

    $buku = new Buku($db);

    $buku->ISBN = $_POST["ISBN"];
    $buku->Judul = $_POST["Judul"];
    $buku->Pengarang = $_POST["Pengarang"];
    $buku->Kategori_ID = $_POST["Kategori_ID"];
    $buku->Penerbit_ID = $_POST["penerbit_id"];
    $buku->Deskripsi = $_POST["Deskripsi"];
    $buku->Stok = $_POST["Stok"];
    $buku->ID = $_POST['id'];

    $buku->update();
}
header("Location: http://localhost/PERPUS_APP/buku/index.php");
?>