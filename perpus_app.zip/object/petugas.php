<?php

class Petugas{
    
    // koneksi database dan nama tabel
    private $conn;
    private $table_name = "Petugas";

    //property object anggota
    public $ID;
    public $NamaPetugas;
    public $Alamat;
    public $NoTelp;
    public $Email;
    public $Passowrd;
    public $Role;

    public function __construct($db) {
      $this->conn = $db;
   }

   function create() {
      //insert
      $query = "INSERT INTO " . $this->table_name . " (Email, NamaPetugas, Alamat, NoTelp, Password, Role)" .
                              " VALUES (:Email, :NamaPetugas, :Alamat, :NoTelp, :Password, :Role)";
      
      $result = $this->conn->prepare($query);

      $this->Email = htmlspecialchars(strip_tags($this->Email));
      $this->NamaPetugas = htmlspecialchars(strip_tags($this->NamaPetugas));
      $this->Alamat = htmlspecialchars(strip_tags($this->Alamat));
      $this->NoTelp = htmlspecialchars(strip_tags($this->NoTelp));
      $this->Password = htmlspecialchars(strip_tags($this->Password));
      $this->Role = htmlspecialchars(strip_tags($this->Role));
      
      $result->bindParam(":Email", $this->Email);
      $result->bindParam(":NamaPetugas", $this->NamaPetugas);
      $result->bindParam(":Alamat", $this->Alamat);
      $result->bindParam(":NoTelp", $this->NoTelp);
      $result->bindParam(":Password", $this->Password);
      $result->bindParam(":Role", $this->Role);
      
      if($result->execute()) {
         return true;    
      } else{
         return false;
      }
  }


   function readAll() {
   //select
   $query = "SELECT * FROM " . $this->table_name;

   $result = $this->conn->prepare($query);
   $result->execute();

   return $result;

   }
   

   function readOne() {
   //select
   $query = "SELECT * FROM " . $this->table_name . " WHERE ID = ?";

   $result = $this->conn->prepare($query);
   $result->bindParam(1, $this->ID);
   $result->execute();

   $row = $result->fetch(PDO::FETCH_ASSOC);

   $this->Email = $row["Email"];
   $this->NamaPetugas = $row["NamaPetugas"];
   $this->Alamat = $row["Alamat"];
   $this->NoTelp = $row["NoTelp"];
   $this->Password = $row["Password"];
   $this->Role = $row["Role"];
   }

   function update() {
      $query = "UPDATE " . $this->table_name . " SET
          Email = :Email,
          NamaPetugas = :NamaPetugas,
          Alamat = :Alamat,
          NoTelp = :NoTelp,
          Password = :Password,
          Role = :Role
          WHERE
          ID = :ID";
      
      $result = $this->conn->prepare($query);
      
      $this->Email = htmlspecialchars(strip_tags($this->Email));
      $this->NamaPetugas = htmlspecialchars(strip_tags($this->NamaPetugas));
      $this->Alamat = htmlspecialchars(strip_tags($this->Alamat));
      $this->NoTelp = htmlspecialchars(strip_tags($this->NoTelp));
      $this->Password = htmlspecialchars(strip_tags($this->Password));
      $this->Role = htmlspecialchars(strip_tags($this->Role));
     
      $result->bindParam(":Email", $this->Email);
      $result->bindParam(":NamaPetugas", $this->NamaPetugas);
      $result->bindParam(":Alamat", $this->Alamat);
      $result->bindParam(":NoTelp", $this->NoTelp);
      $result->bindParam(":Password", $this->Password);
      $result->bindParam(":Role", $this->Role);
      $result->bindParam(":ID", $this->ID);

      $result->execute();
   }  

   function delete() {
      $query = "DELETE FROM " . $this->table_name . " WHERE ID = ?";

      $result = $this->conn->prepare($query);
      $result->bindParam(1, $this->ID);

      $result->execute();
   }

   function authenticate() {
      $query = "SELECT * FROM " . $this->table_name . " WHERE Email = :Email AND Password = :Password";

      $result = $this->conn->prepare($query);

      $this->Email = htmlspecialchars(strip_tags($this->Email));
      $this->Password = htmlspecialchars(strip_tags($this->Password));

      $result->bindParam(":Email", $this->Email);
      $result->bindParam(":Password", $this->Password);

      $result->execute();

      if($result->rowCount() > 0) {
         $petugas = $result->fetch(PDO::FETCH_ASSOC);

         $_SESSION["namapetugas"] = $petugas["NamaPetugas"];
         $_SESSION["rolepetugas"] = $petugas["Role"];
         $_SESSION["idpetugas"] = $petugas["ID"];
         $_SESSION["emailpetugas"] = $petugas["Email"];
         return true;    
      } else{
         echo $result->rowCount();
         return false;
      }
  }
}
?>