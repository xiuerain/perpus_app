<?php
if($_POST) {

    include '../config/Database.php';
    include '../object/Kategori.php';

    $database = new Database();
    $db = $database->getConnection();

    $kategori = new Kategori($db);

    $kategori->NamaKategori = $_POST['namakategori'];
    $kategori->ID = $_POST['id'];

    $kategori->create();
}
header("Location: http://localhost/PERPUS_APP/kategori/index.php");
?>